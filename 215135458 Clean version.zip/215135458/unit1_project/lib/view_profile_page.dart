import 'package:flutter/material.dart';
import 'edit_profile_data.dart';
import 'profile.dart';

class ViewProfilePage extends StatefulWidget {
  const ViewProfilePage({super.key, required this.profile});
  final Profile profile;
  @override
  State<ViewProfilePage> createState() => _ViewProfilePageState();
}

class _ViewProfilePageState extends State<ViewProfilePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueGrey[50],
      appBar: AppBar(
        //I don't see a reason to pop off the context of the navigation
        // since we have the edit button. So I am setting this back button false
        automaticallyImplyLeading: false,
        title: const Text(
          'Profile page',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: EdgeInsets.all(24.0),
        child: Center(
          //I made this scrollable because it's quite possible that the user would
          //have a lot of words in the "role" property
          child: SingleChildScrollView(
            child: Column(
              children: [
                Center(
                  child: CircleAvatar(
                    radius: 100,
                    //Alright let me explain this logic. In a circle avatar there is a
                    //foreground and background image. So here I test to see if the profile
                    //pic has been set. if so then it show in the circle part of the
                    //Circle avatar. If the profile pic is not set then there shouldn't be
                    //anything in the circle part of the Circle avatar.
                    backgroundImage: widget.profile.profilePic != null
                        ? FileImage(widget.profile.profilePic!)
                        : null,
                    //Below is the foreground image where I would like to show a camera
                    //icon if the profile picture was not set but if the profile pic was set then
                    //there shouldn't be a foreground image. It would obscure the profile picture
                    //if it is not set to null.
                    child: widget.profile.profilePic == null
                        ? const Icon(Icons.camera_alt, size: 50)
                        : null,
                  ),
                ),
                const SizedBox(height: 20),
                Center(
                  child: Text(
                    '${widget.profile.name} ${widget.profile.surname}',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Cell: ${widget.profile.cellphoneNr}'),
                    const SizedBox(height: 5),
                    Text('Email: ${widget.profile.email}'),
                    const SizedBox(height: 5),
                    Text('Role: ${widget.profile.role}'),
                    const SizedBox(height: 5),
                    Text('Programming Language: ${widget.profile.prgmLang}'),
                  ],
                ),

                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (context) =>
                            EditProfileData(profile: widget.profile),
                      ),
                    );
                  },
                  child: Text('Edit profile'),
                ),
              ], //End of children
            ),
          ),
        ),
      ),
    );
  }
}
