import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart'; //I added this in the pubspec.yaml
import 'view_profile_page.dart';
import 'profile.dart';
import 'dart:io';

class AddProfile extends StatefulWidget {
  const AddProfile({super.key});

  @override
  State<AddProfile> createState() => _AddProfileState();
}

class _AddProfileState extends State<AddProfile> {
  final nameController = TextEditingController();
  final surnameController = TextEditingController();
  final cellphoneNrController = TextEditingController();
  final emailController = TextEditingController();
  final roleController = TextEditingController();
  final progmLangController = TextEditingController();
  //I am going to use this reference below to pass it into the view page.
  //See the FloatingActionButton before Scaffold closing parenthesis
  //Basically at the bottom of this add_profile.dart document
  Profile? profile;
  //I am going to use the variable below to help me add a profile picture.
  File? _image;
  //Below is an instance of image_picker that I added to the pubspec.yaml
  final _picker = ImagePicker();
  //Below is my own custom Future method to help me choose the profile picture.
  //I plan to call this method in the Elevated button after the circle avatar
  Future<void> pickImage() async {
    //This method requires an ImageSource that can be from the camera or from gallery
    //In this app I am only going to use the gallery image source to keep the app simple
    //oh by the way pickedFile is of type XFile meaning it's temporary until permanently stored
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        //Here is where I set the picked image from the gallery to the profile picture
        //property. I casted the temporary XFile's to a permanent File type to store it
        _image = File(pickedFile.path);
        profile = Profile(profilePic: _image);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    //Since we are adding a new profile, there shouldn't be an existing profile picture
    profile = Profile(profilePic: null);
  }

  //Whenever we work with controller objects it's always a good idea to add them to the
  //dispose method so that they can be destroyed.
  @override
  void dispose() {
    nameController.dispose();
    surnameController.dispose();
    cellphoneNrController.dispose();
    emailController.dispose();
    roleController.dispose();
    progmLangController.dispose();
    super.dispose(); //always invoked last
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Profile'),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        //There's alot going on in the screen so I made it scrollable
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: "Please enter name",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: surnameController,
                decoration: InputDecoration(
                  labelText: "Please enter surname",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: cellphoneNrController,
                decoration: InputDecoration(
                  labelText: "Please enter cellphone number",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "Please enter email",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: roleController,
                decoration: InputDecoration(
                  labelText: "Please enter role",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: progmLangController,
                decoration: InputDecoration(
                  labelText: "Enter programming language",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              Center(
                //It's a must that I test _image and not the profilePic property here
                child: _image == null
                    ? Text("No profile picture selected")
                    : Image.file(_image!),
              ),
              const SizedBox(height: 10),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    //This is my custom Future method using the image_picker package
                    //that I added to the pubspec.yaml file
                    pickImage();
                  },
                  child: Text(
                    "Add a profile Picture",
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ),
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          //Since I will be navigating to a new screen, I need not use the setState() here
          //As promised I am instantiating the Profile object and passing it to the view page
          final profile = Profile(
            name: nameController.text,
            surname: surnameController.text,
            cellphoneNr: cellphoneNrController.text,
            email: emailController.text,
            role: roleController.text,
            prgmLang: progmLangController.text,
            profilePic: _image,
          );

          //Passing the Profile object to the view page
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => ViewProfilePage(profile: profile),
            ),
          );
        },
        child: Icon(Icons.save),
      ),
    );
  }
}
