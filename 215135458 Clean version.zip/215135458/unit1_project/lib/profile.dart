//In order to access the File datatype I have to import this package
import 'dart:io';

class Profile {
  String name;
  String surname;
  String cellphoneNr;
  String email;
  String role;
  String prgmLang;
  //I am declaring the profile pic property as nullable since a profile pic can be empty
  File? profilePic;

  Profile({
    this.name = 'No name added yet',
    this.surname = 'No surname added yet',
    this.cellphoneNr = 'No cellphone number added yet',
    this.email = 'No email address added yet',
    this.role = 'No role added yet',
    this.prgmLang = 'No programming lanuage added yet',
    this.profilePic,
  });
}
