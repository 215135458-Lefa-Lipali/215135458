import 'package:flutter/material.dart';
import 'view_profile_page.dart';
import 'profile.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

class EditProfileData extends StatefulWidget {
  const EditProfileData({super.key, required this.profile});
  final Profile profile;
  @override
  State<EditProfileData> createState() => _EditProfileDataState();
}

class _EditProfileDataState extends State<EditProfileData> {
  final nameController = TextEditingController();
  final surnameController = TextEditingController();
  final cellphoneNrController = TextEditingController();
  final emailController = TextEditingController();
  final roleController = TextEditingController();
  final progmLangController = TextEditingController();
  File? _image;
  //Below is an instance of image_picker that I added to the pubspec.yaml
  final _picker = ImagePicker();

  Future<void> pickImage() async {
    //Okay here I am breaking a programming principle which is to never repeat code logic
    //I won't do it again in future I promise.
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
        widget.profile.profilePic =
            _image; //notice here I am assigning and not instantiating
      });
    }
  }

  @override
  void initState() {
    super.initState();

    //The controllers are initialised for incase user only wants to change
    //a few properties. Without this the user will be forced to edit all properties
    nameController.text = widget.profile.name;
    surnameController.text = widget.profile.surname;
    cellphoneNrController.text = widget.profile.cellphoneNr;
    emailController.text = widget.profile.email;
    roleController.text = widget.profile.role;
    progmLangController.text = widget.profile.prgmLang;
  }

  @override
  void dispose() {
    nameController.dispose();
    surnameController.dispose();
    cellphoneNrController.dispose();
    emailController.dispose();
    roleController.dispose();
    progmLangController.dispose();
    super.dispose(); //always must be called last
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edit Profile',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: "Please enter new name",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: surnameController,
                decoration: InputDecoration(
                  labelText: "Please enter new surname",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: cellphoneNrController,
                decoration: InputDecoration(
                  labelText: "Please enter new cellphone number",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: "Please enter new email",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: roleController,
                decoration: InputDecoration(
                  labelText: "Please enter new role",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: progmLangController,
                decoration: InputDecoration(
                  labelText: "New programming language",
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 10),
              Center(
                child: widget.profile.profilePic == null
                    ? Text("No profile picture selected")
                    : Image.file(widget.profile.profilePic as File),
              ),
              const SizedBox(height: 10),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    pickImage();
                  },
                  child: Text(
                    //This was a last minute change lol after testing
                    //We want it to say "add picture" if a picture was never
                    //stored in the beginning. not "change"
                    widget.profile.profilePic != null
                        ? "Change Picture"
                        : "Add Picture",
                    style: TextStyle(fontSize: 20),
                  ),
                ),
              ),
              //The SizedBox below is so the user can see the floating action
              //button with nothing behind it
              const SizedBox(height: 100),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            //Below the logic is if the controller's text not empty then it should be
            //assigned to the property. Otherwise what was originally assigned to the
            //property must remain stored in the property. This prevents emptiness being
            //stored. Allowing user to change only the values he/she wants to edit

            //For name
            widget.profile.name = nameController.text.isNotEmpty
                ? nameController.text
                : widget.profile.name;
            //For surname
            widget.profile.surname = surnameController.text.isNotEmpty
                ? surnameController.text
                : widget.profile.surname;
            //For cell number
            widget.profile.cellphoneNr = cellphoneNrController.text.isNotEmpty
                ? cellphoneNrController.text
                : widget.profile.cellphoneNr;
            //For email
            widget.profile.email = emailController.text.isNotEmpty
                ? emailController.text
                : widget.profile.email;
            //For role
            widget.profile.role = roleController.text.isNotEmpty
                ? roleController.text
                : widget.profile.role;
            //For language
            widget.profile.prgmLang = progmLangController.text.isNotEmpty
                ? progmLangController.text
                : widget.profile.prgmLang;
            //For profile pic
            Navigator.of(context).push(
              MaterialPageRoute(
                builder: (context) => ViewProfilePage(profile: widget.profile),
              ),
            );
          });
        },
        child: Icon(Icons.save),
      ),
    );
  }
}
