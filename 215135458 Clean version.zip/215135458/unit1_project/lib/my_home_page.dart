import 'package:flutter/material.dart';
import 'add_profile.dart';

//this page is not going to change
class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile App',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true, //By default this sets the title to the left
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'Welcome to the \nProfile App',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 50),
            ElevatedButton(
              onPressed: () {
                Navigator.of(
                  context,
                ).push(MaterialPageRoute(builder: (context) => AddProfile()));
              },
              child: Text('Add a new profile'),
            ),

            const SizedBox(height: 50),
            const Text(
              'Developed by Inheritance\n215135458',
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
